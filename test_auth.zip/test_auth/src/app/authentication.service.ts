import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Router, CanActivate } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    
   
    constructor(private http: HttpClient, private router: Router) { }

    login(employee_id: string, password: string) {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        console.log(currentUser)
        return this.http.post<{ token: string }>(`${environment.BaseUrl}api/login`,
            { employee_id, password }).pipe(tap(res => {
                localStorage.setItem('access_token', res.token);
                console.log(res.token)
                if (!localStorage.getItem('token')) {
                    this.router.navigate(['/list'])
                } else
                    this.router.navigate(['/login'])
            }))
    };

    getToken() {
        return localStorage.getItem('token')
      }
}