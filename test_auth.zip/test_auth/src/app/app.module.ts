import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS  } from "@angular/common/http";
import { JwtModule } from '@auth0/angular-jwt';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LiginComponent } from './ligin/ligin.component';
import { ListComponent } from './list/list.component';
import { AppInterceptorService } from './app-interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    LiginComponent,
    ListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule, 
    JwtModule.forRoot({
      config:{
        tokenGetter:function tokenGetter(){
          return localStorage.getItem(`access_token`)},
          whitelistedDomains:["https://shop-auth-ms.herokuapp.com"],
          blacklistedRoutes:["https://shop-auth-ms.herokuapp.com/api/login"]
      }
    })
  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,
    useClass:AppInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
