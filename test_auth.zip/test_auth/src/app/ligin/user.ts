export class User{
    employeeId: string;
    password: string;
}