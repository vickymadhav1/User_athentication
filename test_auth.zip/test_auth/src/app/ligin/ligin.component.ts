import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from "../authentication.service";

@Component({
    selector: 'app-ligin',
    templateUrl: './ligin.component.html',
    styleUrls: ['./ligin.component.css']
})
export class LiginComponent implements OnInit {

    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
    ) { }
    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            employee_Id: ['', Validators.required],
            password: ['', Validators.required]
        });
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }
    get f() { return this.loginForm.controls; }
    
    onSubmit() {
        this.submitted = true;
        if (this.loginForm.invalid) {
            return;
        }
        this.loading = true;
        this.authenticationService.login(this.f.employee_Id.value, this.f.password.value)
            .pipe(first())
            .subscribe((res: any) => {
                console.log(res)
                this.router.navigate([this.returnUrl]);
            },
                error => {
                    this.loading = false;
                });
    }

}
