import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LiginComponent } from "./ligin/ligin.component";
import { ListComponent } from './list/list.component';


const routes: Routes = [{path:'',pathMatch:'full',redirectTo:`/login`},
{
  path:`login`,
  component:LiginComponent,
},
{path:`list`,
component:ListComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
